package com.codecool.dungeoncrawl;

public class App {
    public static void main(String[] args) {
        Main.main(args);
    }
}
