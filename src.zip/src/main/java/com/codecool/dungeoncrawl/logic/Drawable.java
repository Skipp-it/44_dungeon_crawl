package com.codecool.dungeoncrawl.logic;

public interface Drawable {
    String getTileName();
}
